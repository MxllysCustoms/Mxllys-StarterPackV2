-- Open starter pack menu
local function openStarterPackMenu()
    -- Check if player can claim
    local canClaim = lib.callback.await('starterpack:canClaim', false)
    
    if not canClaim then
        ESX.ShowNotification('You have already claimed a starter pack', 'error')
        return
    end

    -- Get available packs for this player
    local availablePacks = lib.callback.await('starterpack:getAvailablePacks', false)
    
    if not availablePacks or #availablePacks == 0 then
        ESX.ShowNotification('No starter packs available for you', 'error')
        return
    end

    -- Build menu options
    local options = {}
    
    for _, pack in ipairs(availablePacks) do
        table.insert(options, {
            title = pack.label,
            description = pack.description,
            icon = pack.icon,
            iconColor = '#3b82f6',
            onSelect = function()
                -- Confirm selection
                local alert = lib.alertDialog({
                    header = 'Confirm Selection',
                    content = 'Are you sure you want to claim the **' .. pack.label .. '**?  \nYou can only claim a starter pack once!',
                    centered = true,
                    cancel = true
                })

                if alert == 'confirm' then
                    TriggerServerEvent('starterpack:requestPack', pack.id)
                end
            end
        })
    end

    -- Register and show menu
    lib.registerContext({
        id = 'starterpack_menu',
        title = 'Starter Pack Selection',
        options = options,
        position = 'top-right'
    })

    lib.showContext('starterpack_menu')
end

-- Register command to open menu
RegisterCommand(Config.Command, function()
    openStarterPackMenu()
end, false)

-- Export function for other resources
exports('openStarterPackMenu', openStarterPackMenu)
