Config = {}

-- Command to open starter pack menu
Config.Command = 'starterpack'

-- Allow players to claim starter pack only once
Config.OneTimeOnly = true

-- Starter pack types and their items
Config.StarterPacks = {
    {
        id = 'regular',
        label = 'Regular Starter Pack',
        description = 'Basic items to get you started',
        icon = 'box',
        items = {
            { name = 'bread', count = 5 },
            { name = 'water', count = 5 },
            { name = 'phone', count = 1 },
            { name = 'money', count = 5000 }, -- Cash money
        }
    },
    {
        id = 'cop',
        label = 'Police Starter Pack',
        description = 'Equipment for law enforcement officers',
        icon = 'shield-halved',
        jobRequired = 'police', -- Optional: require specific job
        items = {
            { name = 'bread', count = 3 },
            { name = 'water', count = 3 },
            { name = 'phone', count = 1 },
            { name = 'radio', count = 1 },
            { name = 'money', count = 3000 },
        }
    },
    {
        id = 'female',
        label = 'Female Starter Pack',
        description = 'Specialized items for female characters',
        icon = 'venus',
        items = {
            { name = 'bread', count = 5 },
            { name = 'water', count = 5 },
            { name = 'phone', count = 1 },
            { name = 'money', count = 5000 },
        }
    }
}

-- Admin command to delete starter pack records
Config.AdminCommand = 'deletestarterpack'
Config.AdminGroup = 'admin' -- ESX permission group required
