fx_version 'cerulean'
game 'gta5'

author 'Mxllys Customs'
description 'Starter Pack System with Database Tracking Made For Regular, Cops, and Females'
version '2.0.1'

shared_scripts {
    '@es_extended/imports.lua',
    '@ox_lib/init.lua',
    'config.lua'
}

client_scripts {
    'client/main.lua'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/main.lua'
}

dependencies {
    'es_extended',
    'ox_lib',
    'ox_inventory',
    'oxmysql'
}
