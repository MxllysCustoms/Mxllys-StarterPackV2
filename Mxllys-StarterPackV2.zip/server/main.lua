-- Check if player has already claimed a starter pack
local function hasClaimedPack(identifier)
    local result = MySQL.query.await('SELECT * FROM starter_packs WHERE identifier = ?', {identifier})
    return result and #result > 0
end

-- Record starter pack claim in database
local function recordClaim(identifier, packType)
    MySQL.insert('INSERT INTO starter_packs (identifier, pack_type) VALUES (?, ?)', {identifier, packType})
end

-- Give items to player
local function giveStarterPack(source, pack)
    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer then return false end

    for _, item in ipairs(pack.items) do
        if item.name == 'money' then
            xPlayer.addMoney(item.count)
        else
            local canCarry = exports.ox_inventory:CanCarryItem(source, item.name, item.count)
            if canCarry then
                exports.ox_inventory:AddItem(source, item.name, item.count)
            else
                xPlayer.showNotification('Inventory full! Could not give ' .. item.name, 'error')
            end
        end
    end

    return true
end

-- Request starter pack
RegisterNetEvent('starterpack:requestPack', function(packId)
    local source = source
    local xPlayer = ESX.GetPlayerFromId(source)
    
    if not xPlayer then return end

    -- Find the requested pack
    local selectedPack = nil
    for _, pack in ipairs(Config.StarterPacks) do
        if pack.id == packId then
            selectedPack = pack
            break
        end
    end

    if not selectedPack then
        xPlayer.showNotification('Invalid starter pack', 'error')
        return
    end

    -- Check job requirement if exists
    if selectedPack.jobRequired and xPlayer.job.name ~= selectedPack.jobRequired then
        xPlayer.showNotification('You need to be a ' .. selectedPack.jobRequired .. ' to claim this pack', 'error')
        return
    end

    -- Check if already claimed
    if Config.OneTimeOnly then
        local hasClaimed = hasClaimedPack(xPlayer.identifier)
        if hasClaimed then
            xPlayer.showNotification('You have already claimed a starter pack', 'error')
            return
        end
    end

    -- Give items
    local success = giveStarterPack(source, selectedPack)
    
    if success then
        -- Record in database
        recordClaim(xPlayer.identifier, packId)
        xPlayer.showNotification('Starter pack received!', 'success')
    else
        xPlayer.showNotification('Failed to give starter pack', 'error')
    end
end)

-- Check if player can claim (callback for client)
lib.callback.register('starterpack:canClaim', function(source)
    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer then return false end

    if Config.OneTimeOnly then
        return not hasClaimedPack(xPlayer.identifier)
    end
    
    return true
end)

-- Get available packs for player
lib.callback.register('starterpack:getAvailablePacks', function(source)
    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer then return {} end

    local availablePacks = {}
    
    for _, pack in ipairs(Config.StarterPacks) do
        -- Check job requirement
        if not pack.jobRequired or xPlayer.job.name == pack.jobRequired then
            table.insert(availablePacks, {
                id = pack.id,
                label = pack.label,
                description = pack.description,
                icon = pack.icon
            })
        end
    end

    return availablePacks
end)

-- Admin command to delete starter pack record
ESX.RegisterCommand(Config.AdminCommand, Config.AdminGroup, function(xPlayer, args, showError)
    local targetIdentifier = args.identifier

    if not targetIdentifier then
        xPlayer.showNotification('Usage: /' .. Config.AdminCommand .. ' [identifier]', 'error')
        return
    end

    local result = MySQL.query.await('DELETE FROM starter_packs WHERE identifier = ?', {targetIdentifier})
    
    if result and result.affectedRows > 0 then
        xPlayer.showNotification('Deleted starter pack record for ' .. targetIdentifier, 'success')
    else
        xPlayer.showNotification('No record found for ' .. targetIdentifier, 'error')
    end
end, true, {
    help = 'Delete a player\'s starter pack record',
    arguments = {
        {name = 'identifier', help = 'Player identifier', type = 'string'}
    }
})

-- Command to check if player has claimed
ESX.RegisterCommand('checkstarterpack', Config.AdminGroup, function(xPlayer, args, showError)
    local targetIdentifier = args.identifier

    if not targetIdentifier then
        xPlayer.showNotification('Usage: /checkstarterpack [identifier]', 'error')
        return
    end

    local hasClaimed = hasClaimedPack(targetIdentifier)
    
    if hasClaimed then
        local result = MySQL.query.await('SELECT pack_type, received_at FROM starter_packs WHERE identifier = ?', {targetIdentifier})
        if result and #result > 0 then
            local data = result[1]
            xPlayer.showNotification(targetIdentifier .. ' claimed ' .. data.pack_type .. ' on ' .. data.received_at, 'info')
        end
    else
        xPlayer.showNotification(targetIdentifier .. ' has not claimed a starter pack', 'info')
    end
end, true, {
    help = 'Check if player has claimed a starter pack',
    arguments = {
        {name = 'identifier', help = 'Player identifier', type = 'string'}
    }
})
